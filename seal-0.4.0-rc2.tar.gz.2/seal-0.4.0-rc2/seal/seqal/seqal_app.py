
__doc__ = """A module for things shared between the mapper and the reducer."""


PAIR_STRING = "PAIR"
UNMAPPED_STRING = "unmapped"
